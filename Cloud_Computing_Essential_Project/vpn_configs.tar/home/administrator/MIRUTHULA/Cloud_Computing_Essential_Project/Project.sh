touch client_{1..20}

